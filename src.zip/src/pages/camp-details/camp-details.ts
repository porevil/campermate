import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Data } from '../../providers/data';

/*
  Generated class for the CampDetails page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-camp-details',
  templateUrl: 'camp-details.html'
})
export class CampDetailsPage {
  campDetailsForm: FormGroup;
  constructor(public navCtrl: NavController, public formBuilder: FormBuilder,
    public dataService: Data) {

    this.campDetailsForm = formBuilder.group({
      gateAccessCode: [''],
      ammenitiesCode: [''],
      wifiPassword: [''],
      phoneNumber: [''],
      departure: [''],
      notes: ['']
    });

  }

  saveForm(): void {
    // This will return an object that contains all of the values
    let data = this.campDetailsForm.value;
  }

  ionViewDidLoad() {
    console.log('Hello CampDetails Page');
  }

}
